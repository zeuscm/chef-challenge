ufw Cookbook CHANGELOG
======================
This file is used to list changes made in each version of the ufw cookbook.


v0.7.4
------
No change. Version bump for toolchain


v0.7.2
------
Updating metadata to depend on firewall >= 0.9


v0.7.0
------
[COOK-3592] - allow source ports to be defined as a range in ufw


v0.6.4
------
### Bug
- **[COOK-3316](https://tickets.opscode.com/browse/COOK-3316)** - Fix README.md example

v0.6.2
------
### Bug
- [COOK-2487]: when setting a node attribute you must specify the precedence
- [COOK-2982]: ufw cookbook has foodcritic failures
